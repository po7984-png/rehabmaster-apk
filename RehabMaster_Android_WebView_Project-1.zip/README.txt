RehabMaster Android WebView Project
-----------------------------------
This Android Studio project wraps the RehabMaster Progressive Web App (PWA)
for offline use. You can upload this ZIP to GitHub and use the build.yml workflow
to automatically compile the APK file.

Structure:
- app/src/... : contains Android WebView files
- index.html  : entry point for the RehabMaster PWA
- manifest.webmanifest : web app manifest
